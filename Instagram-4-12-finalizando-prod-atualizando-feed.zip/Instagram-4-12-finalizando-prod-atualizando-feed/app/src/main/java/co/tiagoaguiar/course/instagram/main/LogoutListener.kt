package co.tiagoaguiar.course.instagram.main

interface LogoutListener {
  fun logout()
}