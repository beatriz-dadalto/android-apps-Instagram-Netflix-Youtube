package co.tiagoaguiar.course.instagram.common.base

interface BasePresenter {
  fun onDestroy()
}