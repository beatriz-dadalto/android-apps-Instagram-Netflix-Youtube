package co.tiagoaguiar.course.instagram.splash.data

interface SplashCallback {
  fun onSuccess()
  fun onFailure()
}