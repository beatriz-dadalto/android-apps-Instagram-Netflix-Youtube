package co.tiagoaguiar.course.instagram.common.base

interface BaseView<T> {
  var presenter: T
}